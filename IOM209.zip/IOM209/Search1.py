import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


data = pd.read_csv('../IOM209_Individual Coursework/Industry_data_equipment_updated.csv')

def calculate_volatility(sub_df):
    sub_df['Emotion_Change'] = sub_df['GB_emotion'].pct_change()
    threshold = sub_df['Emotion_Change'].quantile(0.75)
    sub_df['High_Volatility'] = (abs(sub_df['Emotion_Change']) > threshold).astype(int)
    return sub_df

data = data.groupby('Scode').apply(calculate_volatility).reset_index(drop=True)


data['SVI_Other'] = data['SVI_All'] - data['SVI_code']


average_svi_high = data[data['High_Volatility'] == 1].groupby('Scode')[['SVI_code', 'SVI_All', 'SVI_Other']].mean()
average_svi_low = data[data['High_Volatility'] == 0].groupby('Scode')[['SVI_code', 'SVI_All', 'SVI_Other']].mean()


change_ratio_svi_code = (average_svi_high['SVI_code'] - average_svi_low['SVI_code']) / average_svi_low['SVI_code']
change_ratio_svi_all = (average_svi_high['SVI_All'] - average_svi_low['SVI_All']) / average_svi_low['SVI_All']
change_ratio_svi_other = (average_svi_high['SVI_Other'] - average_svi_low['SVI_Other']) / average_svi_low['SVI_Other']


increase_code = (change_ratio_svi_code > 0).sum()
decrease_code = (change_ratio_svi_code < 0).sum()
increase_all = (change_ratio_svi_all > 0).sum()
decrease_all = (change_ratio_svi_all < 0).sum()
increase_other = (change_ratio_svi_other > 0).sum()
decrease_other = (change_ratio_svi_other < 0).sum()

fig, axs = plt.subplots(nrows=3, ncols=1, figsize=(10, 12))
sns.histplot(change_ratio_svi_code.dropna(), bins=30, kde=True, ax=axs[0])
axs[0].set_title('Distribution of Change Ratio in SVI_code')
axs[0].set_xlabel('Change Ratio')
axs[0].set_ylabel('Frequency')

sns.histplot(change_ratio_svi_all.dropna(), bins=30, kde=True, ax=axs[1])
axs[1].set_title('Distribution of Change Ratio in SVI_All')
axs[1].set_xlabel('Change Ratio')
axs[1].set_ylabel('Frequency')

sns.histplot(change_ratio_svi_other.dropna(), bins=30, kde=True, ax=axs[2])
axs[2].set_title('Distribution of Change Ratio in SVI_Other')
axs[2].set_xlabel('Change Ratio')
axs[2].set_ylabel('Frequency')

plt.tight_layout()
plt.show()


print(f'Increase in SVI_code: {increase_code}, Decrease in SVI_code: {decrease_code}')
print(f'Increase in SVI_All: {increase_all}, Decrease in SVI_All: {decrease_all}')
print(f'Increase in SVI_Other: {increase_other}, Decrease in SVI_Other: {decrease_other}')
