import pandas as pd
data = pd.read_csv('../IOM209_Individual Coursework/Paneldata.csv')
data.dropna(inplace=True)
data.to_csv('filtered_top_industries_final.csv', index=False)




