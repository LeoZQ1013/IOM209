import pandas as pd


df_a = pd.read_csv('../IOM209_Individual Coursework/stock week.csv', encoding='GBK', low_memory=False)


try:
    df_b = pd.read_csv('../IOM209_Individual Coursework/data_score.csv', encoding='GBK')
except UnicodeDecodeError:

    df_b = pd.read_csv('../IOM209_Individual Coursework/data_score.csv', encoding='utf-8')

df_a['Date'] = pd.to_datetime(df_a['Date'], format='%Y-%m-%d', errors='coerce')
df_b['Date'] = pd.to_datetime(df_b['Date'], format='%Y-%m-%d', errors='coerce')


merged_df = pd.merge(df_b, df_a[['ShortName', 'Date', 'Wopnprc', 'Whiprc', 'Wloprc', 'Wclsprc', 'Wclsprcp', 'Wret', 'Awclsprc', 'Awclsprcp', 'Awret', 'Wtrdvol', 'Wtrdamt', 'Wts', 'Wos', 'Wmktcap', 'Womktcap', 'Wtnor']], on=['ShortName', 'Date'], how='left')


merged_df.to_csv('Paneldata.csv', index=False)

