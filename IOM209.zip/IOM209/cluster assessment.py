import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from tslearn.clustering import TimeSeriesKMeans
from tslearn.metrics import dtw
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler


data = pd.read_csv('../IOM209_Individual Coursework/filtered_top_industries_final.csv')


industry_avg_return = data.groupby(['IndustryCode', 'IndustryName', 'Trdwnt'])['Wretwd'].mean().reset_index()

industry_avg_return['PrevWretwd'] = industry_avg_return.groupby(['IndustryCode', 'IndustryName'])['Wretwd'].shift(1).fillna(0)

industry_avg_return_pivot = industry_avg_return.pivot_table(index='IndustryCode', columns='Trdwnt', values=['Wretwd', 'PrevWretwd'], fill_value=0)

scaler = StandardScaler()
industry_scaled = scaler.fit_transform(industry_avg_return_pivot.values)

X = np.array([industry_scaled])

silhouettes = []
inertia = []
K_range = range(2, 10)
for k in K_range:
    model = TimeSeriesKMeans(n_clusters=k, metric="dtw", max_iter=300, verbose=True)
    labels = model.fit_predict(X[0])

    dist_matrix = np.zeros((len(X[0]), len(X[0])))
    for i in range(len(X[0])):
        for j in range(i + 1, len(X[0])):
            dist = dtw(X[0][i], X[0][j], global_constraint="sakoe_chiba", sakoe_chiba_radius=2)
            dist_matrix[i, j] = dist
            dist_matrix[j, i] = dist
    np.fill_diagonal(dist_matrix, 0)

    if not np.isfinite(dist_matrix).all():
        print("Distance matrix contains non-finite values.")
    else:
        silhouette_avg = silhouette_score(dist_matrix, labels, metric='precomputed')
        silhouettes.append(silhouette_avg)
        print(f"对于聚类数 k = {k}, 轮廓系数为: {silhouette_avg}")

    inertia.append(model.inertia_)


plt.figure(figsize=(12, 5))

plt.subplot(1, 2, 1)
plt.plot(K_range, inertia, marker='o', linestyle='-', color='deepskyblue')
plt.xlabel('Number of clusters')
plt.ylabel('Inertia')
plt.title('Elbow Method For Optimal k')
plt.grid(True)

plt.subplot(1, 2, 2)
plt.plot(K_range, silhouettes, marker='o', linestyle='-', color='salmon')
plt.xlabel('Number of clusters')
plt.ylabel('Silhouette Score')
plt.title('Silhouette Score For Optimal k')
plt.grid(True)


optimal_k = np.argmax(silhouettes) + 2
model = TimeSeriesKMeans(n_clusters=optimal_k, metric="dtw", max_iter=100, verbose=True, random_state=42)
labels = model.fit_predict(X[0])


plt.figure(figsize=(10, 6))
for i in range(optimal_k):
    plt.plot(model.cluster_centers_[i], label=f'Cluster {i}')
plt.legend()
plt.title('Cluster Centers')
plt.show()


industry_avg_return_pivot['Cluster'] = labels


industry_avg_return_pivot['IndustryName'] = industry_avg_return.groupby('IndustryCode')['IndustryName'].first()


optimal_industries = []
for i in range(model.n_clusters):
    cluster_industries = industry_avg_return_pivot[industry_avg_return_pivot['Cluster'] == i]
    center = model.cluster_centers_[i]
    distances = cluster_industries.apply(lambda x: dtw(center, x.drop(['Cluster', 'IndustryName'])), axis=1)
    optimal_industries.append(distances.idxmin())


similar_industries_results = {}
for industry_code in optimal_industries:
    target_series = industry_avg_return_pivot.loc[industry_code].drop(['Cluster', 'IndustryName'])
    distances = industry_avg_return_pivot.drop(industry_code).apply(lambda x: dtw(target_series, x.drop(['Cluster', 'IndustryName'])), axis=1)
    closest_industries = distances.nsmallest(4)
    similar_industries_results[industry_code] = [(idx, industry_avg_return_pivot.loc[idx, 'IndustryName']) for idx in closest_industries.index]

for code, similar in similar_industries_results.items():
    print(f"目标行业代码和名称: {code}, {industry_avg_return_pivot.loc[code, 'IndustryName']}")
    print("最相似的4个行业及名称为：")
    for idx, name in similar:
        print(f"行业代码: {idx}, 行业名称: {name}")
    print("\n")

