import pandas as pd
industry_data = pd.read_csv('../IOM209_Individual Coursework/Industry_data_equipment.csv')
top_30_stocks = pd.read_csv('../IOM209_Individual Coursework/consistent_high_correlation_stocks_data_equipment.csv')
outstanding_stocks = set(top_30_stocks['Scode'])
industry_data['isOutstanding'] = industry_data['Scode'].apply(lambda x: 1 if x in outstanding_stocks else 0)
industry_data.to_csv('Industry_data_equipment_updated.csv', index=False)


