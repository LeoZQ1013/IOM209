import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


data = pd.read_csv('../IOM209_Individual Coursework/Industry_data_equipment_updated.csv')


def calculate_volatility(sub_df):
    sub_df['Emotion_Change'] = sub_df['GB_emotion'].pct_change()
    high_threshold = sub_df['Emotion_Change'].quantile(0.75)
    low_threshold = sub_df['Emotion_Change'].quantile(0.25)
    sub_df['High_Volatility'] = (sub_df['Emotion_Change'] > high_threshold).astype(int)
    sub_df['Low_Volatility'] = (sub_df['Emotion_Change'] < low_threshold).astype(int)
    return sub_df

data = data.groupby('Scode').apply(calculate_volatility).reset_index(drop=True)


average_svi_high = data[data['High_Volatility'] == 1].groupby('Scode')[['SVI_code', 'SVI_All']].mean()
average_svi_low = data[data['Low_Volatility'] == 1].groupby('Scode')[['SVI_code', 'SVI_All']].mean()


change_svi = average_svi_high - average_svi_low
change_svi.dropna(inplace=True)


fig, ax = plt.subplots(figsize=(12, 6))
change_svi_sorted = change_svi.sort_values(by='SVI_code', ascending=False)
sns.barplot(x=change_svi_sorted.index, y='SVI_code', data=change_svi_sorted, ax=ax)
ax.set_title('Change in SVI_code from Low to High Volatility Weeks')
ax.set_xlabel('Stock Code')
ax.set_ylabel('Change in Search Volume')
plt.xticks([])
plt.show()


fig, ax = plt.subplots(figsize=(12, 6))
change_svi_sorted = change_svi.sort_values(by='SVI_All', ascending=False)
sns.barplot(x=change_svi_sorted.index, y='SVI_All', data=change_svi_sorted, ax=ax)
ax.set_title('Change in SVI_Other from Low to High Volatility Weeks')
ax.set_xlabel('Stock Code')
ax.set_ylabel('Change in Search Volume')
plt.xticks([])
plt.show()



