import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import ttest_ind


data = pd.read_csv('../IOM209_Individual Coursework/Industry_data_equipment_updated.csv')


def calculate_volatility(sub_df):
    sub_df['Emotion_Change'] = sub_df['GB_emotion'].pct_change()
    threshold = sub_df['Emotion_Change'].quantile(0.75)
    sub_df['High_Volatility'] = (abs(sub_df['Emotion_Change']) > threshold).astype(int)
    return sub_df


data = data.groupby('Scode').apply(calculate_volatility).reset_index(drop=True)


average_wtnor_high = data[data['High_Volatility'] == 1].groupby('Scode')['Wtnor'].mean()
average_wtnor_low = data[data['High_Volatility'] == 0].groupby('Scode')['Wtnor'].mean()


average_svi_high = data[data['High_Volatility'] == 1].groupby('Scode')['SVI_code'].mean()
average_svi_low = data[data['High_Volatility'] == 0].groupby('Scode')['SVI_code'].mean()
change_ratio_svi_code = (average_svi_high - average_svi_low) / average_svi_low
stocks_increased_search = change_ratio_svi_code[change_ratio_svi_code > 0].index


change_wtnor_increased_search_high = average_wtnor_high.loc[stocks_increased_search]
change_wtnor_increased_search_low = average_wtnor_low.loc[stocks_increased_search]

t_stat, p_value = ttest_ind(change_wtnor_increased_search_high.dropna(), change_wtnor_increased_search_low.dropna(), equal_var=False)
plt.figure(figsize=(10, 6))
sns.kdeplot(change_wtnor_increased_search_high, label='High Volatility', fill=True)
sns.kdeplot(change_wtnor_increased_search_low, label='Low Volatility', fill=True)
plt.title('Distribution of Turnover Rate Change for Stocks with Increased Search Volume')
plt.xlabel('Turnover Rate (Wtnor)')
plt.legend()
plt.show()
print(f'T-statistic: {t_stat}, P-value: {p_value}')
